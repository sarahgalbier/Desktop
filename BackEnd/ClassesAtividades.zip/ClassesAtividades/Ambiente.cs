using System;

namespace ClassesAtividades;

public class Ambiente
{

    public string Nome;

    public double Largura;

    public double Comprimento;

    public Ambiente(string nome, double largura, double comprimento)
    {
       Nome = nome;
       Largura = largura;
       Comprimento= comprimento;
    }

    public void ExibirMedidas()
    {
        Console.WriteLine($"Nome:{Nome}, Largura: {Largura} e Comprimento: {Comprimento}");
    }

    public double CaucularArea()
    {
       return Largura * Comprimento;
        
    }
}
