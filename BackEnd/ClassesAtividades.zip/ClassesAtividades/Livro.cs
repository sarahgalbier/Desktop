using System;

namespace ClassesAtividades;

public class Livro
{
    public string Titulo;

    public string Autorname;

    public int Anopublicacao;

    public Livro(string titulo,string autorname, int anopublicacao)
    {
        Titulo = titulo;
        Autorname = autorname;
        Anopublicacao = anopublicacao;
    }

    public void Exibirficha(){
        Console.WriteLine($"Título: {Titulo}, Autor: {Autorname} e foi publicado em {Anopublicacao}");
    }
}
