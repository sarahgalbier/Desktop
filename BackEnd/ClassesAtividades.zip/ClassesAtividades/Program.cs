﻿using ClassesAtividades;

Livro livro1 = new Livro("Dom Casmurro — edição comentada", "Machado de Assis", 1899);
Livro livro2 = new Livro("O Pequeno Príncipe", "Antoine de Saint-Exupéry", 1943);

livro1.Exibirficha();
livro2.Exibirficha();

Ambiente ambiente1 = new Ambiente("Sala", 4.0, 6.0);
Ambiente ambiente2 = new Ambiente("Quarto", 3.0, 3.5);

ambiente1.ExibirMedidas();
ambiente2.ExibirMedidas();

double area1 = ambiente1.CaucularArea();

double area2 = ambiente2.CaucularArea();


double areatotal = area1 + area2;

Console.WriteLine($"Área {ambiente1.Nome}: {area1}m², Área {ambiente2.Nome}: {area2}m², Área total: {areatotal}m²");



Aluno aluno1 = new Aluno("Carla", "Desenvolvimento de sistema", 5, 7);
Aluno aluno2 = new Aluno("Diego", "Desenvolvimento de sistema", 4, 5);

aluno1.ExibirResultado();
aluno2.ExibirResultado();






Conta conta1 = new Conta("Ana Silva", "001", 0.0);
Conta conta2 = new Conta("Carlos Souza", "002", 0.0);

conta1.Depositar(200.00);
conta1.ExibirSaldo();

conta1.Sacar(50.00);
conta1.ExibirSaldo();

conta1.Sacar(200.00);
conta1.ExibirSaldo();

conta1.Depositar(-10.00);
conta1.ExibirSaldo();

conta2.Depositar(80.00);
conta2.ExibirSaldo();

conta2.Sacar(80.00);
conta2.ExibirSaldo();

conta2.Sacar(0.00);
conta2.ExibirSaldo();