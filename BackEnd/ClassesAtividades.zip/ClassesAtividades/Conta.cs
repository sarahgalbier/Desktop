using System;

namespace ClassesAtividades;

public class Conta
{
    public string Titular;
    public string Numero;
    public double Saldo;

    public Conta(string titular, string numero, double saldo)
    {
        Titular = titular;
        Numero = numero;
        Saldo = saldo;
    }

    public void Depositar(double valor)
    {
        if (valor <= 0)
        {
            Console.WriteLine("Erro: O valor do depósito deve ser maior que zero.");
            return;
        }

        Saldo += valor;
        Console.WriteLine($"Depósito de R$ {valor:F2} realizado com sucesso na conta de {Titular}.");
    }

    public void Sacar(double valor)
    {
        if (valor <= 0)
        {
            Console.WriteLine("Erro: O valor do saque deve ser maior que zero.");
            return;
        }

        if (valor > Saldo)
        {
            Console.WriteLine($"Erro: Saldo insuficiente para realizar o saque de R$ {valor:F2}. Saldo atual: R$ {Saldo:F2}.");
            return;
        }

        Saldo -= valor;
        Console.WriteLine($"Saque de R$ {valor:F2} realizado com sucesso na conta de {Titular}.");
    }

    public void ExibirSaldo()
    {
        Console.WriteLine($"Titular: {Titular}");
        Console.WriteLine($"Número da Conta: {Numero}");
        Console.WriteLine($"Saldo Atual: R$ {Saldo:F2}");
    }
}