using System;
using System.Globalization;

namespace ClassesAtividades;

public class Aluno
{

    public string Nome;

    public string Curso;


    public double Nota1;

    public double Nota2;

    public double media = 0;
    public string situacao = "";

    public Aluno(string nome,string curso, double nota1, double nota2)
    {
        Nome = nome;
        Curso= curso;
        Nota1 = nota1;
        Nota2 =nota2;
        

    }
   
    public double CalcularMedia()
    {
        
        media = ((Nota1 + Nota2)/2);

        if(media >= 6)
        {
            situacao = "Aprovado";
        }
        else
        {
            situacao="Reprovado";
        }

        return media;
    }

    
     public void ExibirResultado()
    {
        CalcularMedia();
        Console.WriteLine($"Nome:{Nome}, Curso: {Curso} Média: {media:f1}, Situação: {situacao}");
    }



}


